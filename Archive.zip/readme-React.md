Hi,
this is my first react project and repo 
It is all base on work for school 
https://novi.nl

Full me please!